package com.myrepro

import android.app.*
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Binder
import android.os.IBinder

class PlaybackService : Service() {
    inner class B : Binder() { val service get() = this@PlaybackService }
    lateinit var engine: MixEngine
    lateinit var beats: BeatCache
    var ui: (() -> Unit)? = null
    private val CH = "myrepro"

    override fun onBind(i: Intent?): IBinder = B()

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Reproducción", NotificationManager.IMPORTANCE_LOW))
        beats = BeatCache(this)
        engine = MixEngine(this) { beats.request(engine.current, engine.upcoming); startForeground(1, build()); ui?.invoke() }
        engine.beats = { beats.get(it) }
        startForeground(1, build())
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        when (i?.action) { "T" -> engine.toggle(); "N" -> engine.next(); "P" -> engine.prev() }
        return START_STICKY
    }

    private fun act(a: String, icon: Int, t: String) = Notification.Action.Builder(
        Icon.createWithResource(this, icon), t,
        PendingIntent.getService(this, a.hashCode(), Intent(this, PlaybackService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE)).build()

    private fun build(): Notification {
        val title = engine.current?.mediaMetadata?.title ?: "MyRepro"
        val playIcon = if (engine.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE))
            .addAction(act("P", android.R.drawable.ic_media_previous, "Anterior"))
            .addAction(act("T", playIcon, "Play/Pausa"))
            .addAction(act("N", android.R.drawable.ic_media_next, "Siguiente"))
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)).build()
    }

    override fun onTaskRemoved(r: Intent?) { if (!engine.isPlaying) stopSelf() }
    override fun onDestroy() { engine.release(); super.onDestroy() }
}
