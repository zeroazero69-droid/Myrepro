package com.myrepro

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.*

data class Beat(val bpm: Double, val offsetMs: Double)

/** Decodifica ~30 s del centro de la canción, calcula la envolvente de ataques y estima BPM y fase del beat. */
object BpmAnalyzer {
    fun analyze(ctx: Context, uri: Uri): Beat? = try { run(ctx, uri) } catch (e: Exception) { null }

    private fun run(ctx: Context, uri: Uri): Beat? {
        val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
        var codec: MediaCodec? = null
        try {
            val ti = (0 until ex.trackCount).firstOrNull {
                ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true } ?: return null
            ex.selectTrack(ti)
            val fmt = ex.getTrackFormat(ti)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            val win = 30
            ex.seekTo(maxOf(0L, minOf(durUs / 2 - win * 500_000L, 45_000_000L)), MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val startUs = ex.sampleTime.coerceAtLeast(0L)
            codec = MediaCodec.createDecoderByType(mime); codec.configure(fmt, null, null, 0); codec.start()
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val env = ArrayList<Float>()
            var acc = 0.0; var cnt = 0; var lp = 0f
            val info = MediaCodec.BufferInfo(); var inDone = false; var outDone = false
            while (!outDone && env.size < win * 200) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10000)
                    if (i >= 0) {
                        val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                        if (n < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10000)
                if (o >= 0) {
                    val sb = codec.getOutputBuffer(o)!!.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val hop = sr / 200
                    while (sb.remaining() >= ch) {
                        var s = 0f; repeat(ch) { s += sb.get() }; s /= ch * 32768f
                        lp += 0.1f * (s - lp); acc += lp * lp                    // graves: kick/bajo
                        if (++cnt >= hop) { env.add(sqrt(acc / cnt).toFloat()); acc = 0.0; cnt = 0 }
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = codec.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            val n = env.size
            if (n < 1000) return null
            val d = FloatArray(n) { if (it == 0) 0f else max(0f, env[it] - env[it - 1]) }
            val m = d.average().toFloat(); for (i in 0 until n) d[i] -= m
            val ac = DoubleArray(202)
            for (lag in 60..200) { var s = 0.0; for (i in lag until n) s += d[i] * d[i - lag]; ac[lag] = s / (n - lag) }
            var best = 67; var bv = -1e30
            for (lag in 67..171) {
                val w = exp(-0.5 * (ln(12000.0 / lag / 120.0) / 0.8).pow(2))   // favorece ~120 BPM
                if (ac[lag] * w > bv) { bv = ac[lag] * w; best = lag }
            }
            val den = ac[best - 1] - 2 * ac[best] + ac[best + 1]
            val lagF = best + if (den != 0.0) 0.5 * (ac[best - 1] - ac[best + 1]) / den else 0.0
            val nb = lagF.roundToInt(); val bins = DoubleArray(nb)
            for (i in 0 until n) bins[((i % lagF) / lagF * nb).toInt().coerceAtMost(nb - 1)] += d[i].toDouble()
            val bb = bins.indices.maxByOrNull { bins[it] } ?: 0
            return Beat(12000.0 / lagF, startUs / 1000.0 + (bb + 0.5) * lagF / nb * 5.0)
        } finally { codec?.release(); ex.release() }
    }
}
