package com.myrepro

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

class MainActivity : Activity() {
    private var svc: PlaybackService? = null
    private val titles = ArrayList<String>()
    private val items = ArrayList<MediaItem>()
    private lateinit var now: TextView
    private lateinit var list: ListView
    private lateinit var bar: SeekBar
    private lateinit var time: TextView
    private var dragging = false
    private val h = Handler(Looper.getMainLooper())
    private val audioPerm get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                                  else Manifest.permission.READ_EXTERNAL_STORAGE

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            svc = (b as PlaybackService.B).service
            svc!!.ui = { refresh() }; refresh()
        }
        override fun onServiceDisconnected(n: ComponentName) { svc = null }
    }

    private val updater = object : Runnable {
        override fun run() {
            svc?.engine?.let { e ->
                if (!dragging && e.duration > 0) {
                    bar.progress = (e.position * 1000 / e.duration).toInt()
                    time.text = fmt(e.position) + " / " + fmt(e.duration)
                }
            }
            h.postDelayed(this, 500)
        }
    }
    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)
    private fun refresh() {
        val e = svc?.engine
        val bpm = e?.current?.let { svc?.beats?.get(it) }?.let { "\n♪ %.1f BPM".format(it.bpm) } ?: ""
        now.text = (if (e?.isPlaying == true) "▶ " else "⏸ ") + (e?.current?.mediaMetadata?.title ?: "MyRepro") + bpm
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
        val perms = mutableListOf(audioPerm)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED) { load(); startSvc() }
        else requestPermissions(perms.toTypedArray(), 1)
        h.post(updater)
    }

    private fun startSvc() {
        val i = Intent(this, PlaybackService::class.java)
        startForegroundService(i); bindService(i, conn, BIND_AUTO_CREATE)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED) { load(); startSvc() }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null); svc?.ui = null
        try { unbindService(conn) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun toggleBtn(t: String, init: Boolean, on: (Boolean) -> Unit) = Button(this).apply {
        text = t; alpha = if (init) 1f else 0.4f
        setOnClickListener { val s = alpha < 1f; alpha = if (s) 1f else 0.4f; on(s) }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        now = TextView(this).apply { textSize = 18f; text = "MyRepro"; setPadding(0, 0, 0, 16) }
        list = ListView(this)
        bar = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar) {
                    svc?.engine?.let { it.seekTo(it.duration * s.progress / 1000) }; dragging = false
                }
            })
        }
        time = TextView(this).apply { text = "0:00 / 0:00"; gravity = Gravity.END }
        val lbl = TextView(this).apply { text = "Mezcla (crossfade): 6 s" }
        val mix = SeekBar(this).apply {
            max = 12; progress = 6
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    val v = p.coerceAtLeast(1); lbl.text = "Mezcla (crossfade): $v s"
                    svc?.engine?.fadeMs = v * 1000L
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(toggleBtn("🥁", true) { svc?.engine?.beatmatch = it })
        row.addView(toggleBtn("🔀", false) { svc?.engine?.setShuffle(it) })
        row.addView(Button(this).apply { text = "⏮"; setOnClickListener { svc?.engine?.prev() } })
        row.addView(Button(this).apply { text = "⏯"; setOnClickListener { svc?.engine?.toggle() } })
        row.addView(Button(this).apply { text = "⏭"; setOnClickListener { svc?.engine?.next() } })
        row.addView(toggleBtn("🔁", false) { svc?.engine?.repeat = it })
        for (k in 0 until row.childCount) (row.getChildAt(k) as Button).apply {
            minWidth = 0; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        root.addView(now); root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar); root.addView(time); root.addView(lbl); root.addView(mix); root.addView(row)
        setContentView(root)
        list.setOnItemClickListener { _, _, pos, _ -> svc?.engine?.play(items, pos) }
    }

    private fun load() {
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(base,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
            "${MediaStore.Audio.Media.IS_MUSIC}!=0", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use {
            while (it.moveToNext()) {
                val name = "${it.getString(1)} — ${it.getString(2)}"
                titles.add(name)
                items.add(MediaItem.Builder().setUri(ContentUris.withAppendedId(base, it.getLong(0)))
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build()).build())
            }
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, titles)
    }
}
