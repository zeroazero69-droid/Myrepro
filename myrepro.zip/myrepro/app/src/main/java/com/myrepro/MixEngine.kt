package com.myrepro

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Dos reproductores con crossfade de potencia constante, aleatorio, repetir y recorte de silencios. */
class MixEngine(ctx: Context, var onChange: () -> Unit) {
    private val h = Handler(Looper.getMainLooper())
    private fun mk() = ExoPlayer.Builder(ctx).build().apply {
        setSkipSilenceEnabled(true); setHandleAudioBecomingNoisy(true)
    }
    private var cur = mk()
    private var nxt = mk()
    private var items = listOf<MediaItem>()
    private var order = mutableListOf<Int>()
    private var pos = 0
    var fadeMs = 6000L
    var shuffle = false; private set
    var repeat = false
    private var fading = false
    private var elapsed = 0L
    private var curFade = 6000L
    private val step = 50L
    var beats: (MediaItem) -> Beat? = { null }
    var beatmatch = true
    private var nxtSpeed = 1f
    private var rampFrom = 1f
    private var rampT = -1L
    val upcoming: MediaItem? get() = if (hasNext) items[order[nextPos]] else null

    val current: MediaItem? get() = order.getOrNull(pos)?.let { items.getOrNull(it) }
    val isPlaying get() = cur.playWhenReady
    val position get() = cur.currentPosition
    val duration get() = cur.duration.takeIf { it != C.TIME_UNSET } ?: 0L
    private val hasNext get() = pos + 1 < order.size || (repeat && order.isNotEmpty())
    private val nextPos get() = if (pos + 1 < order.size) pos + 1 else 0

    private val tick = object : Runnable {
        override fun run() {
            if (cur.playWhenReady) {
                if (!fading) {
                    val d = cur.duration
                    if (d != C.TIME_UNSET && hasNext) {
                        val f = minOf(fadeMs, d / 2)
                        if (d - cur.currentPosition <= f * 1.1) startFade(f)
                    }
                    if (rampT >= 0) {
                        rampT += step
                        val t = (rampT / 8000f).coerceIn(0f, 1f)
                        if (rampT % 200L < step) cur.playbackParameters = PlaybackParameters(rampFrom + (1 - rampFrom) * t)
                        if (t >= 1f) rampT = -1
                    }
                } else {
                    elapsed += step
                    val t = (elapsed.toFloat() / curFade).coerceIn(0f, 1f)
                    cur.volume = cos(t * PI / 2).toFloat()
                    nxt.volume = sin(t * PI / 2).toFloat()
                    if (t >= 1f) finish()
                }
            }
            h.postDelayed(this, step)
        }
    }
    init { h.post(tick) }

    private fun buildOrder(first: Int) {
        order = (items.indices).toMutableList()
        if (shuffle) { order.shuffle(); order.remove(first); order.add(0, first); pos = 0 } else pos = first
    }

    fun play(list: List<MediaItem>, i: Int) { items = list; buildOrder(i); playAt(pos) }

    private fun playAt(p: Int) {
        pos = p; fading = false; nxt.stop(); cur.volume = 1f
        cur.playbackParameters = PlaybackParameters.DEFAULT; nxt.playbackParameters = PlaybackParameters.DEFAULT
        rampT = -1; nxtSpeed = 1f
        cur.setMediaItem(items[order[p]]); cur.prepare(); cur.play(); onChange()
    }

    private fun startFade(f: Long) {
        fading = true; elapsed = 0; curFade = f
        nxt.volume = 0f
        val item = items[order[nextPos]]
        var startMs = 0L; nxtSpeed = 1f
        val a = current?.let { beats(it) }; val b = beats(item)
        if (beatmatch && a != null && b != null) {
            var bb = b.bpm
            while (bb > a.bpm * 1.5) bb /= 2
            while (bb < a.bpm / 1.5) bb *= 2
            if (bb / a.bpm in 0.9..1.1) {
                val target = (a.bpm + bb) / 2                       // ambas se encuentran a mitad de camino
                cur.playbackParameters = PlaybackParameters((target / a.bpm).toFloat())
                nxtSpeed = (target / bb).toFloat()
                nxt.playbackParameters = PlaybackParameters(nxtSpeed)
                val pa = 60000.0 / a.bpm; val pb = 60000.0 / bb
                val phase = (((cur.currentPosition - a.offsetMs) % pa) + pa) % pa / pa   // fase del beat actual
                startMs = (b.offsetMs + phase * pb).toLong()          // entra alineada al mismo beat
                while (startMs < 0) startMs += pb.toLong()
            }
        }
        nxt.setMediaItem(item, startMs); nxt.prepare(); nxt.play()
    }

    private fun finish() {
        cur.stop(); val t = cur; cur = nxt; nxt = t
        cur.volume = 1f; pos = nextPos; fading = false
        nxt.playbackParameters = PlaybackParameters.DEFAULT
        if (nxtSpeed != 1f) { rampFrom = nxtSpeed; rampT = 0 } else rampT = -1
        nxtSpeed = 1f; onChange()
    }

    fun next() { if (items.isNotEmpty() && hasNext) playAt(nextPos) }
    fun prev() {
        if (items.isEmpty()) return
        if (cur.currentPosition > 3000 || pos == 0) cur.seekTo(0) else playAt(pos - 1)
    }
    fun toggle() {
        if (items.isEmpty()) return
        if (cur.playWhenReady) { cur.pause(); if (fading) nxt.pause() }
        else { cur.play(); if (fading) nxt.play() }
        onChange()
    }
    fun seekTo(ms: Long) { if (!fading) cur.seekTo(ms) }
    fun setShuffle(on: Boolean) {
        shuffle = on
        if (items.isNotEmpty()) { val c = order[pos]; buildOrder(c) }
    }
    fun release() { h.removeCallbacksAndMessages(null); cur.release(); nxt.release() }
}
