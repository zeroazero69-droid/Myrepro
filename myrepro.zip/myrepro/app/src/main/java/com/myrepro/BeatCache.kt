package com.myrepro

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** Analiza en segundo plano la canción actual y la siguiente; guarda los resultados en disco. */
class BeatCache(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("beats", Context.MODE_PRIVATE)
    private val map = ConcurrentHashMap<String, Beat>()
    private val tried = ConcurrentHashMap.newKeySet<String>()
    private val pool = Executors.newSingleThreadExecutor()

    init {
        for ((k, v) in prefs.all) (v as? String)?.split("|")?.let { if (it.size == 2) map[k] = Beat(it[0].toDouble(), it[1].toDouble()) }
    }
    private fun key(i: MediaItem) = i.localConfiguration?.uri?.toString()
    fun get(i: MediaItem): Beat? = key(i)?.let { map[it] }
    fun request(vararg items: MediaItem?) {
        for (it in items) {
            val k = it?.let { key(it) } ?: continue
            if (map.containsKey(k) || !tried.add(k)) continue
            pool.execute {
                BpmAnalyzer.analyze(ctx, Uri.parse(k))?.let { b ->
                    map[k] = b; prefs.edit().putString(k, "${b.bpm}|${b.offsetMs}").apply()
                }
            }
        }
    }
}
